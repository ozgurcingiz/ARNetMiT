#' @export
createMirnaListfromDisease <- function(mirnaGeneData,diseaseMirnaData,disease,diseaseIndice)
{
  #diseaseName=as.character(diseaseData[diseaseIndice,2]); diseaseData
  diseaseName= as.character(disease[diseaseIndice,1]);
  ind=which(diseaseMirnaData[,2]==diseaseName)
  newData=diseaseMirnaData[ind,]
  abc=which(as.character(mirnaGeneData[,1]) %in% as.character(newData[,1]));
  mirnaGeneData=mirnaGeneData[abc,];
  mirnaGeneData



  # first param: mirna-target gene data
  # second param: disease- mirna data
  # third param: disease list
  # fourth param: disease indice in list
}

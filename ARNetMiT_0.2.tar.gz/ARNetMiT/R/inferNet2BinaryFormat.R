#' @export
inferNet2BinaryFormat <- function(net,genes, filtering="s") # directed param is a must
  # inferNet2BinaryFormat <- function(net,genes,directed=FALSE, filtering="s") modified in 1 jan 2017
{
  values=matrix();


  if(filtering=="sc")  # # modified 1 jan 2017
  {
    netTemp=net*t(net);
    indices=which(netTemp>0,arr.ind=TRUE);



  }
  else if(filtering=="s")
  { indices=which(net>0,arr.ind=TRUE); # first column is row, second is column so we formed confidence matrices by using columns as denominator}
    #indices=which(net>0,arr.ind=TRUE); # first column is row, second is column so we formed confidence matrices by using columns as denominator
  }

  else {print("Enter correct parameter, s for supoor based filtering, sc for support & confidence based filtering");}


   #if(directed==FALSE) # modified 1 jan 2017
   #{
   indices=ganet.UniqNetSimp(indices);
   #} # difference of undirected-directed network
   class(indices)="numeric";


  secondColumn=as.matrix(genes[indices[,1]]); #secondColumn=as.matrix(genes[indices[,1],1]);
  firstColumn=as.matrix(genes[indices[,2]]); #secondColumn=as.matrix(genes[indices[,2],1]); # columns must be parent and direction is from column to row
  interactions=cbind(firstColumn,secondColumn);
  interactions[,1]=toupper(interactions[,1]);
  interactions[,2]=toupper(interactions[,2]);
  for(i in 1:nrow(indices)) {values[i]=as.numeric(net[indices[i,1],indices[i,2]]);}

  genesDetail=cbind(interactions[,1:2],values);

  if(filtering=="s")
  {
    colnames(genesDetail)=c("First Gene","Second Gene", "Support");  # ASSIGN COLUMN NAMES
  }

  if(filtering=="sc")
  {
    colnames(genesDetail)=c("First Gene","Second Gene", "Confidence");  # ASSIGN COLUMN NAMES
  }



  ind=which(as.matrix(genesDetail[,1])!=as.matrix(genesDetail[,2]));
  genesDetail=genesDetail[ind,];


  if(filtering=="s") # modified in 1 jan 2017, if(directed==FALSE)
  {
    genesDetail=genesDetail[order(genesDetail[,"Support"],decreasing=TRUE),]; # SORT ACCORDING TO MI VALUES

    idx <- !duplicated(t(apply(genesDetail[,1:2], 1, sort))); # ELEMINATE REPEATED AND LOWER MI VALUES

    genesDetail=genesDetail[idx,];
  }

  if(filtering=="sc") # modified in 1 jan 2017, if(directed==FALSE)
  {
    genesDetail=genesDetail[order(genesDetail[,"Confidence"],decreasing=TRUE),]; # SORT ACCORDING TO MI VALUES

    idx <- !duplicated(t(apply(genesDetail[,1:2], 1, sort))); # ELEMINATE REPEATED AND LOWER MI VALUES

    genesDetail=genesDetail[idx,];
  }

  genesDetail=genesDetail[!duplicated(genesDetail[,1:2]), ];
  genesDetail

  res2= new.env();
  assign("indices",indices,envir=res2);
  assign("interactions",genesDetail,envir=res2);
  res2

}



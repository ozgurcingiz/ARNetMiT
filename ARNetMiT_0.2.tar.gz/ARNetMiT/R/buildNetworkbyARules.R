#' @export
buildNetworkbyARules <- function(dataset,support,confidenceVal=0.5,supportType="rank",filtering="s") #buildNetworkbyARules <- function(dataset,support,confidenceVal=0.5,supportType="rank", directed=FALSE)
{

    ptm <- proc.time();
    uni_genes=unique(dataset[,2]);
    h=hash();
    first_step=matrix(data=NA,nrow=length(uni_genes),ncol=2);
    for(i in 1:length(uni_genes))
    {
      tempIndices=which(as.matrix(dataset[,2])==as.character(uni_genes[i]));
      first_step[i,1]=as.character(uni_genes[i]);
      first_step[i,2]=length(tempIndices);
      .set(h,keys=as.character(uni_genes[i]),values=tempIndices);      # indices of all genes are retrieved
    }

    if(supportType=="rank")
    {occur_val=max(as.numeric(first_step[,2]))*support;}

    else if(supportType=="firstQuartile")
    {
      occur_val=quantile(as.numeric(first_step[,2]))[2];
    }
    else if(supportType=="median")
    {
      occur_val=quantile(as.numeric(first_step[,2]))[3];
    }
    else if(supportType=="thirdQuartile")
    {
      occur_val=quantile(as.numeric(first_step[,2]))[4];
    }
    else if(supportType=="mean")
    {
      occur_val=mean(as.numeric(first_step[,2]));
    }
    else {print("enter correct support type and value")}


    temp_ind=which(as.numeric(first_step[,2])>occur_val);
    first_step=first_step[temp_ind,];      # first elimination of eclat using support value


    ##### BEGINING OF SECOND STEP #######

    interact_binary=matrix(data=NA,nrow=nrow(first_step),ncol=nrow(first_step));

    ntemp=nrow(first_step);

    counter=ntemp*(ntemp-1);
    tempCounter=1;

    #geneMirna=character(length = counter);
    geneMirna=matrix(data=NA, nrow=counter, ncol=3);
    followPattern= matrix(data=NA,nrow=counter,ncol=2);

    for (j in 1:nrow(first_step) )
    {
      tempJ=values(h,keys=as.character(first_step[j,1])); # obtain indices of genes
      targetMirna= dataset[tempJ,1]; # obtain mirna's of the gene

      for (k in 1:j )  #for (k in 1:nrow(first_step) )
      {
        if(j!=k)
        {

            tempN=values(h,keys=as.character(first_step[k,1]));
            foundMirna=dataset[tempN,1];
            intersection=which(targetMirna%in%foundMirna); # ortak mirna'lari cikarir ve foundMirna'daki indisi alir .
            if(length(intersection)==0) {
              mirnaColumn="-";
            }
            else
            {
              mirnaColumn=targetMirna[intersection];

              mirnaColumn=paste(mirnaColumn, collapse = ','); # two genes and its related mirna's

            }

            geneMirna[tempCounter,1]=as.character(first_step[j,1]);
            geneMirna[tempCounter,2]=as.character(first_step[k,1]);
            geneMirna[tempCounter,3]=mirnaColumn; # two genes and its related mirna's

            followPattern[tempCounter,1]=as.character(first_step[j,1]);
            followPattern[tempCounter,2]=as.character(first_step[k,1]);



            #if(length(intersection)==0) {intersection=0;}

            interact_binary[j,k]=length(intersection); # shows how many common mirna between two genes
            colnames(interact_binary)=first_step[,1];

            tempCounter=tempCounter+1;
        }

       }
    }

    diag(interact_binary)=0;

#     tempind=which(as.matrix(geneMirna[,3])!="-");
#     geneMirna=geneMirna[tempind,];
#     followPattern=followPattern[tempind,];

    ### make symteric ###
    indo=upper.tri(interact_binary);
    interact_binary[indo]=t(interact_binary)[indo];

    # SECOND SUPPORT ELIMINATION

    #support2=max(interact_binary)*support;

    if(supportType=="rank")
    {support2=max(interact_binary)*support;}

    else if(supportType=="firstQuartile")
    {
      support2=quantile(as.matrix(interact_binary))[2];
    }
    else if(supportType=="median")
    {
      support2=quantile(as.matrix(interact_binary))[3];
    }
    else if(supportType=="thirdQuartile")
    {
      support2=quantile(as.matrix(interact_binary))[4];
    }
    else if(supportType=="mean")
    {
      support2=mean(as.matrix(interact_binary));
    }
    else {print("enter correct support type and value")}

    interact_binary[interact_binary<support2]=0; # second elimination due to support value

    tempFirstStep=matrix(data=NA, nrow=length(first_step[,1]),ncol=length(first_step[,1]));
    tempFirstStep[,1:nrow(first_step)]=as.numeric(first_step[1:nrow(first_step),2]);
    tempSecondStep=tempFirstStep;
    tempFirstStep=t(tempFirstStep);

    confidenceTable= interact_binary/tempFirstStep; #  p(AuB) / p(A)
    confidenceTable=confidenceTable/max(confidenceTable); #normalization step
    confidenceTable[confidenceTable<confidenceVal]=0;

    liftTable= (interact_binary*length(unique(dataset[,1])))/ (tempFirstStep*tempSecondStep); ## p(AuB) / p(A)* P(B) -- divisor have two divisor so multiplication becomes must. divisor is # of unique miRNA

    if(filtering=="sc")  # if(directed==TRUE)
    {
      res2=inferNet2BinaryFormat(confidenceTable,first_step[,1],filtering="sc"); #res2=inferNet2BinaryFormat(confidenceTable,first_step[,1],directed=TRUE)
      finalIndices=res2$indices;
      finalNetwork=res2$interactions;
    }
    else if(filtering=="s") # else if(directed==FALSE)
    {
      res2=inferNet2BinaryFormat(interact_binary,first_step[,1],filtering="s");
      finalIndices=res2$indices;
      finalNetwork=res2$interactions;
    }


    eleminatedCouples=ganet.ComLinks(netlist= as.matrix(followPattern[,1:2]), netdata=as.matrix(finalNetwork[,1:2]));
    #eleminatedCouples=ganet.ComLinks(netlist= as.matrix(finalNetwork[,1:2]), netdata=as.matrix(followPattern));
    finalNetIndices=as.numeric(eleminatedCouples[,3]);
    geneMirna=geneMirna[finalNetIndices,];

    colnames(first_step)=c("Gene Name","Count");
    colnames(geneMirna)=c("First Gene","Second Gene","Common miRNAs");

    res= new.env();
    #assign("hastable",h,envir=res);
    assign("firstStep",first_step,envir=res);
    assign("binaryInteractions",interact_binary,envir=res);
    assign("confidenceTable",confidenceTable,envir=res);
    assign("liftTable",liftTable,envir=res);
    assign("finalNetwork",finalNetwork,envir=res);
    assign("geneMirna",geneMirna,envir=res);

    #finalNetwork=ganet.UniqNetSimp(finalNetwork);
    visualizeNet(finalNetwork);  #  visualizeNet(finalNetwork,directed);

    print(proc.time() - ptm)

    #write.table(geneMirna,"geneMirna.txt")

    res

}

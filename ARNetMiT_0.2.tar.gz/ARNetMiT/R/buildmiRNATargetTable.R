#' @export
buildmiRNATargetTable <- function(dataset)
{
  dataset=GAnet::ganet.UniqNetSimp(dataset);
  myTable=as.data.frame(table(as.data.frame(dataset)));
  miRNAs=as.matrix(unique(myTable[,1]));
  genes=as.matrix(unique(myTable[,2]));

  fullMatrix=matrix(data=0, nrow=length(genes), ncol=length(miRNAs));

  ind=which(myTable[,3]>0);

  geneIndices= ceiling(ind / length(miRNAs));
  #print(max(geneIndices))

  miRNAIndices=ind %% length(miRNAs);

  miRNAIndices[miRNAIndices==0]=length(miRNAs);
  for (j in 1: length(ind)) {fullMatrix[geneIndices[j],miRNAIndices[j]]=1;}

  rownames(fullMatrix)= c(genes);
  colnames(fullMatrix)= c(miRNAs);
  fullMatrix


}

#' @export
visualizeNet <- function(network) # #visualizeNet <- function(network,directed=FALSE)
{
    #if(directed==FALSE) # modified in 1 jan 2017
    #{
      ge <- graph.data.frame(network[,1:2], directed = FALSE);
    #}

#     if(directed==TRUE) # modified in 1 jan 2017
#     {
#       ge <- graph.data.frame(network[,1:2], directed = TRUE);
#     }

    ge <- set.edge.attribute(ge, "weight", value=as.numeric(network[,3]));

    E(ge)$edgeWidth <- as.numeric(network[,3])*300;

    ge <- simplify(ge);


    rdp <- RedPort('MyPort');
    calld(rdp);
    addGraph( rdp, ge, layout.random(ge) );
    #summary(ge);


}
